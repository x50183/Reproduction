Upload this folder to Overleaf and compile with XeLaTeX. Figures are stored in figures/.
